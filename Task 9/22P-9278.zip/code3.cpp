#include <unistd.h>
 int main()
 {
int pid; // for storing fork() return 05 int pfd[2]; // for pipe
int pfd[2];
char aString[20]; // Temporary storage 07
pipe(pfd); // create our pipe

}
