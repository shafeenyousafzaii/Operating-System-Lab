#include <stdio.h>
#include <stdlib.h>

int main() {
    char *str = "12345";
    char c = 's';
    int x,y,z;

    // y = atoi(str);
    // printf("The Value of y %d\n", y);
    
    // On One Character
    z = (int)(c);
    printf("The Value of z = %d\n", z);

    return 0;
}