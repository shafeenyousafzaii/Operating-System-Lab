#include <stdio.h>

int main() {
    printf("Hy I am C-File\n");
    return 0;
}