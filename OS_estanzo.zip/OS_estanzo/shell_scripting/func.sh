#!/bin/bash
add() {
    c=`expr ${1} + ${2}`
    echo "addition = ${c}"
}

add 5 10