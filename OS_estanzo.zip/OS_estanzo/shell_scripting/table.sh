#!/bin/bash
echo "Enter The Number which Table You Want: "
read table_num
for i in 1 2 3 4 5 6 7 8 9 10
do
q=`expr ${table_num} \* ${i}`
echo ${table_num} "*" ${i} " = " ${q}
done