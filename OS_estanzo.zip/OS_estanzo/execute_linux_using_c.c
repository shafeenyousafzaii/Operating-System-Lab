#include <stdio.h>
#include <stdlib.h>
int main() {
	printf("Executing Linux Command In C Using the System Command \n ");
	system("ls -lh");
	return 0;
}

