#!/bin/bash
# echo " what do you want"
# read n
for i in $(ls)
do
vi $i
done
